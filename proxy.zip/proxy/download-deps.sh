#!/bin/bash
# Download dependencies script for corporate environments
# Run this script on a machine that has internet access,
# then copy the vendor-local folder to your corporate machine

set -e

VENDOR_DIR="./vendor-local"

echo "============================================"
echo "Downloading Go dependencies locally"
echo "============================================"
echo ""

# Create directory structure
echo "Creating directory structure..."
mkdir -p "$VENDOR_DIR/github.com/elazarl"
mkdir -p "$VENDOR_DIR/github.com/coder"
mkdir -p "$VENDOR_DIR/github.com/inconshreveable"
mkdir -p "$VENDOR_DIR/github.com/stretchr"
mkdir -p "$VENDOR_DIR/github.com/davecgh"
mkdir -p "$VENDOR_DIR/github.com/pmezard"
mkdir -p "$VENDOR_DIR/gopkg.in"
mkdir -p "$VENDOR_DIR/golang.org/x"

# Function to clone or update repo
clone_or_update() {
    local url=$1
    local dir=$2
    local branch=$3

    if [ -d "$dir" ]; then
        echo "  Updating $dir..."
        cd "$dir" && git pull 2>/dev/null || true && cd - > /dev/null
    else
        echo "  Cloning $url..."
        if [ -n "$branch" ]; then
            git clone --branch "$branch" --depth 1 "$url" "$dir"
        else
            git clone --depth 1 "$url" "$dir"
        fi
    fi
}

echo ""
echo "--- Main Dependencies ---"

echo "Downloading github.com/elazarl/goproxy..."
clone_or_update "https://github.com/elazarl/goproxy.git" "$VENDOR_DIR/github.com/elazarl/goproxy"

echo "Downloading gopkg.in/yaml.v3..."
clone_or_update "https://github.com/go-yaml/yaml.git" "$VENDOR_DIR/gopkg.in/yaml.v3" "v3"

echo ""
echo "--- Goproxy Dependencies ---"

echo "Downloading github.com/coder/websocket..."
clone_or_update "https://github.com/coder/websocket.git" "$VENDOR_DIR/github.com/coder/websocket"

echo "Downloading github.com/inconshreveable/go-vhost..."
clone_or_update "https://github.com/inconshreveable/go-vhost.git" "$VENDOR_DIR/github.com/inconshreveable/go-vhost"

echo ""
echo "--- Testing Dependencies ---"

echo "Downloading github.com/stretchr/testify..."
clone_or_update "https://github.com/stretchr/testify.git" "$VENDOR_DIR/github.com/stretchr/testify"

echo "Downloading github.com/davecgh/go-spew..."
clone_or_update "https://github.com/davecgh/go-spew.git" "$VENDOR_DIR/github.com/davecgh/go-spew"

echo "Downloading github.com/pmezard/go-difflib..."
clone_or_update "https://github.com/pmezard/go-difflib.git" "$VENDOR_DIR/github.com/pmezard/go-difflib"

echo ""
echo "--- Golang.org/x Packages ---"

echo "Downloading golang.org/x/net..."
clone_or_update "https://github.com/golang/net.git" "$VENDOR_DIR/golang.org/x/net"

echo "Downloading golang.org/x/text..."
clone_or_update "https://github.com/golang/text.git" "$VENDOR_DIR/golang.org/x/text"

echo "Downloading golang.org/x/sys..."
clone_or_update "https://github.com/golang/sys.git" "$VENDOR_DIR/golang.org/x/sys"

echo "Downloading golang.org/x/crypto..."
clone_or_update "https://github.com/golang/crypto.git" "$VENDOR_DIR/golang.org/x/crypto"

echo "Downloading golang.org/x/sync..."
clone_or_update "https://github.com/golang/sync.git" "$VENDOR_DIR/golang.org/x/sync"

echo "Downloading golang.org/x/time..."
clone_or_update "https://github.com/golang/time.git" "$VENDOR_DIR/golang.org/x/time"

echo ""
echo "============================================"
echo "All dependencies downloaded successfully!"
echo "============================================"
echo ""
echo "Directory structure:"
echo ""
find "$VENDOR_DIR" -maxdepth 4 -type d
echo ""
echo "Total size:"
du -sh "$VENDOR_DIR"
echo ""
echo "Next steps:"
echo "1. Copy the entire 'vendor-local' folder to your corporate machine"
echo "2. Place it inside the project directory"
echo "3. Run: go build ./cmd/proxy"
echo ""
