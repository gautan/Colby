package config

import (
	"os"
	"time"

	"gopkg.in/yaml.v3"
)

// Provider defines a content provider endpoint for URL rewriting.
// URL pattern: /{CP}/{path}?{query} → {scheme}://{host}:{port}/{path}?{query}
type Provider struct {
	Name          string `yaml:"name"`
	Host          string `yaml:"host"`
	Port          int    `yaml:"port"`
	Region        string `yaml:"region"`
	UseHTTPS      bool   `yaml:"use_https"`
	SkipTLSVerify bool   `yaml:"skip_tls_verify"`
}

// Config holds all configuration for the proxy
type Config struct {
	Server     ServerConfig        `yaml:"server"`
	Logging    LoggingConfig       `yaml:"logging"`
	Middleware MiddlewareConfig    `yaml:"middleware"`
	Handlers   HandlersConfig      `yaml:"handlers"`
	Providers  map[string]Provider `yaml:"providers"`
}

// ServerConfig holds server settings
type ServerConfig struct {
	Port         string        `yaml:"port"`
	Verbose      bool          `yaml:"verbose"`
	ReadTimeout  time.Duration `yaml:"read_timeout"`
	WriteTimeout time.Duration `yaml:"write_timeout"`
	IdleTimeout  time.Duration `yaml:"idle_timeout"`
}

// LoggingConfig holds logging settings
type LoggingConfig struct {
	Level  string `yaml:"level"`  // debug, info, warn, error
	Format string `yaml:"format"` // json, text
}

// MiddlewareConfig holds all middleware configurations
type MiddlewareConfig struct {
	Logging   LoggingMiddlewareConfig   `yaml:"logging"`
	Auth      AuthMiddlewareConfig      `yaml:"auth"`
	RateLimit RateLimitMiddlewareConfig `yaml:"rate_limit"`
	Headers   HeadersMiddlewareConfig   `yaml:"headers"`
	Rewrite   RewriteMiddlewareConfig   `yaml:"rewrite"`
}

// LoggingMiddlewareConfig for request/response logging
type LoggingMiddlewareConfig struct {
	Enabled       bool     `yaml:"enabled"`
	LogBody       bool     `yaml:"log_body"`
	MaxBodySize   int      `yaml:"max_body_size"`
	ExcludePaths  []string `yaml:"exclude_paths"`
	IncludeHeaders []string `yaml:"include_headers"`
}

// AuthMiddlewareConfig for authentication
type AuthMiddlewareConfig struct {
	Enabled    bool              `yaml:"enabled"`
	Type       string            `yaml:"type"` // basic, bearer, api_key
	Users      map[string]string `yaml:"users"` // username:password for basic auth
	APIKeys    []string          `yaml:"api_keys"`
	HeaderName string            `yaml:"header_name"` // for api_key auth
}

// RateLimitMiddlewareConfig for rate limiting
type RateLimitMiddlewareConfig struct {
	Enabled       bool `yaml:"enabled"`
	RequestsPerSec int  `yaml:"requests_per_sec"`
	BurstSize     int  `yaml:"burst_size"`
	ByIP          bool `yaml:"by_ip"`
}

// HeadersMiddlewareConfig for header manipulation
type HeadersMiddlewareConfig struct {
	Enabled       bool              `yaml:"enabled"`
	AddRequest    map[string]string `yaml:"add_request"`
	RemoveRequest []string          `yaml:"remove_request"`
	AddResponse   map[string]string `yaml:"add_response"`
	RemoveResponse []string         `yaml:"remove_response"`
}

// RewriteMiddlewareConfig for URL rewriting
type RewriteMiddlewareConfig struct {
	Enabled bool          `yaml:"enabled"`
	Rules   []RewriteRule `yaml:"rules"`
}

// RewriteRule defines a URL rewrite rule
type RewriteRule struct {
	Match   string `yaml:"match"`   // regex pattern
	Replace string `yaml:"replace"` // replacement pattern
}

// HandlersConfig holds handler configurations
type HandlersConfig struct {
	BlockList []string `yaml:"block_list"` // domains to block
	AllowList []string `yaml:"allow_list"` // domains to allow (whitelist mode)
}

// Load reads configuration from a YAML file
func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	var cfg Config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, err
	}

	// Apply defaults for zero values
	applyDefaults(&cfg)

	return &cfg, nil
}

// Default returns default configuration
func Default() *Config {
	cfg := &Config{}
	applyDefaults(cfg)
	return cfg
}

func applyDefaults(cfg *Config) {
	if cfg.Server.Port == "" {
		cfg.Server.Port = "8080"
	}
	if cfg.Server.ReadTimeout == 0 {
		cfg.Server.ReadTimeout = 30 * time.Second
	}
	if cfg.Server.WriteTimeout == 0 {
		cfg.Server.WriteTimeout = 30 * time.Second
	}
	if cfg.Server.IdleTimeout == 0 {
		cfg.Server.IdleTimeout = 60 * time.Second
	}
	if cfg.Logging.Level == "" {
		cfg.Logging.Level = "info"
	}
	if cfg.Logging.Format == "" {
		cfg.Logging.Format = "text"
	}
	if cfg.Middleware.RateLimit.RequestsPerSec == 0 {
		cfg.Middleware.RateLimit.RequestsPerSec = 100
	}
	if cfg.Middleware.RateLimit.BurstSize == 0 {
		cfg.Middleware.RateLimit.BurstSize = 50
	}
	if cfg.Middleware.Auth.HeaderName == "" {
		cfg.Middleware.Auth.HeaderName = "X-API-Key"
	}
	if cfg.Middleware.Logging.MaxBodySize == 0 {
		cfg.Middleware.Logging.MaxBodySize = 1024
	}
}
