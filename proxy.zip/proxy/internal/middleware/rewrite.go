package middleware

import (
	"net/http"
	"net/url"
	"regexp"

	"github.com/elazarl/goproxy"
	"goproxy-custom/internal/config"
	"goproxy-custom/internal/logger"
)

// CompiledRule holds a compiled rewrite rule
type CompiledRule struct {
	Pattern *regexp.Regexp
	Replace string
}

// RegisterRewrite registers the URL rewriting middleware
func RegisterRewrite(proxy *goproxy.ProxyHttpServer, cfg config.RewriteMiddlewareConfig, log *logger.Logger) {
	// Compile all rules
	var compiledRules []CompiledRule
	for _, rule := range cfg.Rules {
		pattern, err := regexp.Compile(rule.Match)
		if err != nil {
			log.Error("Invalid rewrite pattern", "pattern", rule.Match, "error", err)
			continue
		}
		compiledRules = append(compiledRules, CompiledRule{
			Pattern: pattern,
			Replace: rule.Replace,
		})
	}

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			originalURL := r.URL.String()

			for _, rule := range compiledRules {
				if rule.Pattern.MatchString(originalURL) {
					newURLStr := rule.Pattern.ReplaceAllString(originalURL, rule.Replace)
					newURL, err := url.Parse(newURLStr)
					if err != nil {
						log.Error("Failed to parse rewritten URL",
							"original", originalURL,
							"rewritten", newURLStr,
							"error", err,
						)
						continue
					}

					log.Debug("URL rewritten",
						"original", originalURL,
						"rewritten", newURLStr,
					)

					r.URL = newURL
					// Update host header if host changed
					if newURL.Host != "" && newURL.Host != r.Host {
						r.Host = newURL.Host
					}
					break // Apply first matching rule only
				}
			}

			return r, nil
		})
}

// PathPrefixRewrite rewrites URL paths with a prefix
func PathPrefixRewrite(proxy *goproxy.ProxyHttpServer, prefix, replacement string, log *logger.Logger) {
	pattern := regexp.MustCompile("^" + regexp.QuoteMeta(prefix))

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			if pattern.MatchString(r.URL.Path) {
				originalPath := r.URL.Path
				r.URL.Path = pattern.ReplaceAllString(r.URL.Path, replacement)
				log.Debug("Path prefix rewritten",
					"original", originalPath,
					"rewritten", r.URL.Path,
				)
			}
			return r, nil
		})
}

// HostRewrite rewrites the target host
func HostRewrite(proxy *goproxy.ProxyHttpServer, hostMap map[string]string, log *logger.Logger) {
	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			if newHost, ok := hostMap[r.Host]; ok {
				log.Debug("Host rewritten",
					"original", r.Host,
					"rewritten", newHost,
				)
				r.URL.Host = newHost
				r.Host = newHost
			}
			return r, nil
		})
}
