package middleware

import (
	"crypto/tls"
	"fmt"
	"net/http"
	"net/url"
	"regexp"
	"strings"

	"github.com/elazarl/goproxy"
	"bl-go-proxy/internal/config"
	"bl-go-proxy/internal/logger"
)

// CompiledRule holds a compiled rewrite rule
type CompiledRule struct {
	Pattern *regexp.Regexp
	Replace string
}

// RegisterRewrite registers the URL rewriting middleware
func RegisterRewrite(proxy *goproxy.ProxyHttpServer, cfg config.RewriteMiddlewareConfig, log *logger.Logger) {
	// Compile all rules
	var compiledRules []CompiledRule
	for _, rule := range cfg.Rules {
		pattern, err := regexp.Compile(rule.Match)
		if err != nil {
			log.Error("Invalid rewrite pattern", "pattern", rule.Match, "error", err)
			continue
		}
		compiledRules = append(compiledRules, CompiledRule{
			Pattern: pattern,
			Replace: rule.Replace,
		})
	}

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			originalURL := r.URL.String()

			for _, rule := range compiledRules {
				if rule.Pattern.MatchString(originalURL) {
					newURLStr := rule.Pattern.ReplaceAllString(originalURL, rule.Replace)
					newURL, err := url.Parse(newURLStr)
					if err != nil {
						log.Error("Failed to parse rewritten URL",
							"original", originalURL,
							"rewritten", newURLStr,
							"error", err,
						)
						continue
					}

					log.Debug("URL rewritten",
						"original", originalURL,
						"rewritten", newURLStr,
					)

					r.URL = newURL
					// Update host header if host changed
					if newURL.Host != "" && newURL.Host != r.Host {
						r.Host = newURL.Host
					}
					break // Apply first matching rule only
				}
			}

			return r, nil
		})
}

// PathPrefixRewrite rewrites URL paths with a prefix
func PathPrefixRewrite(proxy *goproxy.ProxyHttpServer, prefix, replacement string, log *logger.Logger) {
	pattern := regexp.MustCompile("^" + regexp.QuoteMeta(prefix))

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			if pattern.MatchString(r.URL.Path) {
				originalPath := r.URL.Path
				r.URL.Path = pattern.ReplaceAllString(r.URL.Path, replacement)
				log.Debug("Path prefix rewritten",
					"original", originalPath,
					"rewritten", r.URL.Path,
				)
			}
			return r, nil
		})
}

// HostRewrite rewrites the target host
func HostRewrite(proxy *goproxy.ProxyHttpServer, hostMap map[string]string, log *logger.Logger) {
	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			if newHost, ok := hostMap[r.Host]; ok {
				log.Debug("Host rewritten",
					"original", r.Host,
					"rewritten", newHost,
				)
				r.URL.Host = newHost
				r.Host = newHost
			}
			return r, nil
		})
}

// RegisterProviderRewrite registers provider-based URL rewriting.
// Incoming URL pattern: /{CP}/{path}?{query}
// Rewritten to:         {scheme}://{provider.host}:{port}/{CP}/{path}?{query}
// The first path segment is matched (case-insensitive) against the providers map.
func RegisterProviderRewrite(proxy *goproxy.ProxyHttpServer, providers map[string]config.Provider, log *logger.Logger) {
	// Pre-build a reusable transport for providers that skip TLS verification
	insecureTransport := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}

	for name, p := range providers {
		scheme := "http"
		if p.UseHTTPS {
			scheme = "https"
		}
		target := fmt.Sprintf("%s://%s", scheme, p.Host)
		if p.Port != 0 {
			target = fmt.Sprintf("%s:%d", target, p.Port)
		}
		log.Info("Registered content provider",
			"name", name,
			"target", target,
			"region", p.Region,
			"skip_tls_verify", p.SkipTLSVerify,
		)
	}

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			path := r.URL.Path
			if path == "" || path == "/" {
				return r, nil
			}

			// Extract the first path segment as the content provider name
			trimmed := strings.TrimPrefix(path, "/")
			parts := strings.SplitN(trimmed, "/", 2)
			cpName := strings.ToUpper(parts[0])

			provider, ok := providers[cpName]
			if !ok {
				return r, nil // not a provider route, pass through
			}

			// Build target URL: {scheme}://{host}:{port}/{remaining path}
			scheme := "http"
			if provider.UseHTTPS {
				scheme = "https"
			}

			targetHost := provider.Host
			if provider.Port != 0 {
				targetHost = fmt.Sprintf("%s:%d", provider.Host, provider.Port)
			}
			targetURL := fmt.Sprintf("%s://%s%s", scheme, targetHost, path)
			if r.URL.RawQuery != "" {
				targetURL += "?" + r.URL.RawQuery
			}

			newURL, err := url.Parse(targetURL)
			if err != nil {
				log.Error("Failed to parse provider URL",
					"provider", cpName,
					"target", targetURL,
					"error", err,
				)
				return r, nil
			}

			log.Info("Provider rewrite",
				"provider", cpName,
				"original", r.URL.String(),
				"target", newURL.String(),
			)

			// Preserve original host in X-Forwarded-Host header
			r.Header.Set("X-Forwarded-Host", r.Host)

			r.URL = newURL
			r.Host = newURL.Host

			// Use insecure transport for providers that skip TLS verification
			if provider.SkipTLSVerify && provider.UseHTTPS {
				ctx.RoundTripper = goproxy.RoundTripperFunc(
					func(req *http.Request, ctx *goproxy.ProxyCtx) (*http.Response, error) {
						return insecureTransport.RoundTrip(req)
					})
			}

			return r, nil
		})
}
