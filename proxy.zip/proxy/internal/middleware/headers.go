package middleware

import (
	"net/http"

	"github.com/elazarl/goproxy"
	"github.com/yourorg/goproxy-custom/internal/config"
	"github.com/yourorg/goproxy-custom/internal/logger"
)

// RegisterHeaders registers the header manipulation middleware
func RegisterHeaders(proxy *goproxy.ProxyHttpServer, cfg config.HeadersMiddlewareConfig, log *logger.Logger) {
	// Request header manipulation
	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			// Add headers
			for key, value := range cfg.AddRequest {
				r.Header.Set(key, value)
				log.Debug("Added request header", "key", key, "value", value)
			}

			// Remove headers
			for _, key := range cfg.RemoveRequest {
				r.Header.Del(key)
				log.Debug("Removed request header", "key", key)
			}

			return r, nil
		})

	// Response header manipulation
	proxy.OnResponse().DoFunc(
		func(resp *http.Response, ctx *goproxy.ProxyCtx) *http.Response {
			if resp == nil {
				return nil
			}

			// Add headers
			for key, value := range cfg.AddResponse {
				resp.Header.Set(key, value)
				log.Debug("Added response header", "key", key, "value", value)
			}

			// Remove headers
			for _, key := range cfg.RemoveResponse {
				resp.Header.Del(key)
				log.Debug("Removed response header", "key", key)
			}

			return resp
		})
}

// CommonSecurityHeaders returns common security headers to add
func CommonSecurityHeaders() map[string]string {
	return map[string]string{
		"X-Content-Type-Options":    "nosniff",
		"X-Frame-Options":           "DENY",
		"X-XSS-Protection":          "1; mode=block",
		"Strict-Transport-Security": "max-age=31536000; includeSubDomains",
		"Referrer-Policy":           "strict-origin-when-cross-origin",
	}
}

// CORSHeaders returns CORS headers
func CORSHeaders(allowOrigin string) map[string]string {
	return map[string]string{
		"Access-Control-Allow-Origin":      allowOrigin,
		"Access-Control-Allow-Methods":     "GET, POST, PUT, DELETE, OPTIONS",
		"Access-Control-Allow-Headers":     "Content-Type, Authorization, X-Requested-With",
		"Access-Control-Allow-Credentials": "true",
		"Access-Control-Max-Age":           "86400",
	}
}
