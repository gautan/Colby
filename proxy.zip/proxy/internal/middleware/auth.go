package middleware

import (
	"encoding/base64"
	"net/http"
	"strings"

	"github.com/elazarl/goproxy"
	"bl-go-proxy/internal/config"
	"bl-go-proxy/internal/logger"
)

// RegisterAuth registers the authentication middleware
func RegisterAuth(proxy *goproxy.ProxyHttpServer, cfg config.AuthMiddlewareConfig, log *logger.Logger) {
	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			var authenticated bool
			var authMethod string

			switch cfg.Type {
			case "basic":
				authenticated, authMethod = authenticateBasic(r, cfg.Users)
			case "bearer":
				authenticated, authMethod = authenticateBearer(r, cfg.APIKeys)
			case "api_key":
				authenticated, authMethod = authenticateAPIKey(r, cfg.HeaderName, cfg.APIKeys)
			default:
				// No auth configured, allow all
				return r, nil
			}

			if !authenticated {
				log.Warn("Authentication failed",
					"method", r.Method,
					"url", r.URL.String(),
					"remote_addr", r.RemoteAddr,
					"auth_type", cfg.Type,
				)

				return r, goproxy.NewResponse(r,
					goproxy.ContentTypeText,
					http.StatusProxyAuthRequired,
					"Proxy authentication required",
				)
			}

			log.Debug("Authentication successful",
				"method", r.Method,
				"url", r.URL.String(),
				"auth_method", authMethod,
			)

			return r, nil
		})
}

// authenticateBasic checks Basic authentication
func authenticateBasic(r *http.Request, users map[string]string) (bool, string) {
	auth := r.Header.Get("Proxy-Authorization")
	if auth == "" {
		auth = r.Header.Get("Authorization")
	}

	if !strings.HasPrefix(auth, "Basic ") {
		return false, ""
	}

	decoded, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(auth, "Basic "))
	if err != nil {
		return false, ""
	}

	parts := strings.SplitN(string(decoded), ":", 2)
	if len(parts) != 2 {
		return false, ""
	}

	username, password := parts[0], parts[1]
	if expectedPassword, ok := users[username]; ok && expectedPassword == password {
		return true, "basic:" + username
	}

	return false, ""
}

// authenticateBearer checks Bearer token authentication
func authenticateBearer(r *http.Request, validTokens []string) (bool, string) {
	auth := r.Header.Get("Authorization")
	if !strings.HasPrefix(auth, "Bearer ") {
		return false, ""
	}

	token := strings.TrimPrefix(auth, "Bearer ")
	for _, validToken := range validTokens {
		if token == validToken {
			return true, "bearer"
		}
	}

	return false, ""
}

// authenticateAPIKey checks API key authentication
func authenticateAPIKey(r *http.Request, headerName string, validKeys []string) (bool, string) {
	apiKey := r.Header.Get(headerName)
	if apiKey == "" {
		// Also check query parameter
		apiKey = r.URL.Query().Get("api_key")
	}

	for _, validKey := range validKeys {
		if apiKey == validKey {
			return true, "api_key"
		}
	}

	return false, ""
}
