package middleware

import (
	"bytes"
	"io"
	"net/http"
	"time"

	"github.com/elazarl/goproxy"
	"goproxy-custom/internal/logger"
)

// RegisterLogging registers the logging middleware
func RegisterLogging(proxy *goproxy.ProxyHttpServer, log *logger.Logger) {
	// Log incoming requests
	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			ctx.UserData = time.Now() // Store start time

			log.Info("Request received",
				"method", r.Method,
				"url", r.URL.String(),
				"host", r.Host,
				"remote_addr", r.RemoteAddr,
				"user_agent", r.UserAgent(),
				"content_length", r.ContentLength,
			)

			return r, nil
		})

	// Log responses
	proxy.OnResponse().DoFunc(
		func(resp *http.Response, ctx *goproxy.ProxyCtx) *http.Response {
			if resp == nil {
				return nil
			}

			duration := time.Duration(0)
			if startTime, ok := ctx.UserData.(time.Time); ok {
				duration = time.Since(startTime)
			}

			log.Info("Response sent",
				"method", ctx.Req.Method,
				"url", ctx.Req.URL.String(),
				"status", resp.StatusCode,
				"duration_ms", duration.Milliseconds(),
				"content_length", resp.ContentLength,
			)

			return resp
		})
}

// RequestBodyLogger wraps a request body for logging
type RequestBodyLogger struct {
	body   io.ReadCloser
	buf    *bytes.Buffer
	maxLen int
}

// NewRequestBodyLogger creates a new body logger
func NewRequestBodyLogger(body io.ReadCloser, maxLen int) *RequestBodyLogger {
	return &RequestBodyLogger{
		body:   body,
		buf:    &bytes.Buffer{},
		maxLen: maxLen,
	}
}

func (r *RequestBodyLogger) Read(p []byte) (n int, err error) {
	n, err = r.body.Read(p)
	if r.buf.Len() < r.maxLen {
		r.buf.Write(p[:min(n, r.maxLen-r.buf.Len())])
	}
	return
}

func (r *RequestBodyLogger) Close() error {
	return r.body.Close()
}

func (r *RequestBodyLogger) String() string {
	return r.buf.String()
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
