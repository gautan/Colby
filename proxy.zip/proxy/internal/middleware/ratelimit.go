package middleware

import (
	"net"
	"net/http"
	"sync"
	"time"

	"github.com/elazarl/goproxy"
	"goproxy-custom/internal/config"
	"goproxy-custom/internal/logger"
)

// RateLimiter implements a token bucket rate limiter
type RateLimiter struct {
	mu             sync.Mutex
	tokens         map[string]*bucket
	rate           int           // tokens per second
	burst          int           // max tokens
	cleanupTicker  *time.Ticker
	byIP           bool
}

type bucket struct {
	tokens     float64
	lastUpdate time.Time
}

// NewRateLimiter creates a new rate limiter
func NewRateLimiter(rate, burst int, byIP bool) *RateLimiter {
	rl := &RateLimiter{
		tokens:        make(map[string]*bucket),
		rate:          rate,
		burst:         burst,
		byIP:          byIP,
		cleanupTicker: time.NewTicker(time.Minute),
	}

	// Cleanup old entries periodically
	go rl.cleanup()

	return rl
}

func (rl *RateLimiter) cleanup() {
	for range rl.cleanupTicker.C {
		rl.mu.Lock()
		now := time.Now()
		for key, b := range rl.tokens {
			if now.Sub(b.lastUpdate) > time.Minute*5 {
				delete(rl.tokens, key)
			}
		}
		rl.mu.Unlock()
	}
}

// Allow checks if a request should be allowed
func (rl *RateLimiter) Allow(key string) bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	now := time.Now()
	b, exists := rl.tokens[key]
	if !exists {
		b = &bucket{
			tokens:     float64(rl.burst),
			lastUpdate: now,
		}
		rl.tokens[key] = b
	}

	// Refill tokens based on time elapsed
	elapsed := now.Sub(b.lastUpdate).Seconds()
	b.tokens += elapsed * float64(rl.rate)
	if b.tokens > float64(rl.burst) {
		b.tokens = float64(rl.burst)
	}
	b.lastUpdate = now

	// Check if we have tokens available
	if b.tokens >= 1 {
		b.tokens--
		return true
	}

	return false
}

// getClientIP extracts the client IP from request
func getClientIP(r *http.Request) string {
	// Check X-Forwarded-For header
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		ips := splitAndTrim(xff, ",")
		if len(ips) > 0 {
			return ips[0]
		}
	}

	// Check X-Real-IP header
	if xri := r.Header.Get("X-Real-IP"); xri != "" {
		return xri
	}

	// Fall back to RemoteAddr
	ip, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return ip
}

func splitAndTrim(s, sep string) []string {
	var result []string
	for _, part := range splitString(s, sep) {
		trimmed := trimSpace(part)
		if trimmed != "" {
			result = append(result, trimmed)
		}
	}
	return result
}

func splitString(s, sep string) []string {
	var result []string
	start := 0
	for i := 0; i < len(s); i++ {
		if string(s[i]) == sep {
			result = append(result, s[start:i])
			start = i + 1
		}
	}
	result = append(result, s[start:])
	return result
}

func trimSpace(s string) string {
	start := 0
	end := len(s)
	for start < end && (s[start] == ' ' || s[start] == '\t') {
		start++
	}
	for end > start && (s[end-1] == ' ' || s[end-1] == '\t') {
		end--
	}
	return s[start:end]
}

// RegisterRateLimit registers the rate limiting middleware
func RegisterRateLimit(proxy *goproxy.ProxyHttpServer, cfg config.RateLimitMiddlewareConfig, log *logger.Logger) {
	limiter := NewRateLimiter(cfg.RequestsPerSec, cfg.BurstSize, cfg.ByIP)

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			var key string
			if cfg.ByIP {
				key = getClientIP(r)
			} else {
				key = "global"
			}

			if !limiter.Allow(key) {
				log.Warn("Rate limit exceeded",
					"key", key,
					"method", r.Method,
					"url", r.URL.String(),
				)

				resp := goproxy.NewResponse(r,
					goproxy.ContentTypeText,
					http.StatusTooManyRequests,
					"Rate limit exceeded. Please slow down.",
				)
				resp.Header.Set("Retry-After", "1")
				return r, resp
			}

			return r, nil
		})
}
