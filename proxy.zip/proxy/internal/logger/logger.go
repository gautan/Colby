package logger

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"strings"
	"time"
)

// Level represents log level
type Level int

const (
	DEBUG Level = iota
	INFO
	WARN
	ERROR
)

// Logger is a simple structured logger
type Logger struct {
	level  Level
	format string // json or text
	output io.Writer
}

// LogEntry represents a structured log entry
type LogEntry struct {
	Timestamp string                 `json:"timestamp"`
	Level     string                 `json:"level"`
	Message   string                 `json:"message"`
	Fields    map[string]interface{} `json:"fields,omitempty"`
}

// New creates a new logger
func New(level, format string) *Logger {
	return &Logger{
		level:  parseLevel(level),
		format: format,
		output: os.Stdout,
	}
}

func parseLevel(level string) Level {
	switch strings.ToLower(level) {
	case "debug":
		return DEBUG
	case "info":
		return INFO
	case "warn", "warning":
		return WARN
	case "error":
		return ERROR
	default:
		return INFO
	}
}

func (l *Logger) log(level Level, msg string, keyvals ...interface{}) {
	if level < l.level {
		return
	}

	entry := LogEntry{
		Timestamp: time.Now().UTC().Format(time.RFC3339),
		Level:     levelString(level),
		Message:   msg,
		Fields:    make(map[string]interface{}),
	}

	// Parse key-value pairs
	for i := 0; i < len(keyvals)-1; i += 2 {
		key, ok := keyvals[i].(string)
		if !ok {
			key = fmt.Sprintf("%v", keyvals[i])
		}
		entry.Fields[key] = keyvals[i+1]
	}

	if l.format == "json" {
		data, _ := json.Marshal(entry)
		fmt.Fprintln(l.output, string(data))
	} else {
		// Text format
		var fields string
		for k, v := range entry.Fields {
			fields += fmt.Sprintf(" %s=%v", k, v)
		}
		fmt.Fprintf(l.output, "%s [%s] %s%s\n", entry.Timestamp, entry.Level, entry.Message, fields)
	}
}

func levelString(level Level) string {
	switch level {
	case DEBUG:
		return "DEBUG"
	case INFO:
		return "INFO"
	case WARN:
		return "WARN"
	case ERROR:
		return "ERROR"
	default:
		return "INFO"
	}
}

// Debug logs at debug level
func (l *Logger) Debug(msg string, keyvals ...interface{}) {
	l.log(DEBUG, msg, keyvals...)
}

// Info logs at info level
func (l *Logger) Info(msg string, keyvals ...interface{}) {
	l.log(INFO, msg, keyvals...)
}

// Warn logs at warn level
func (l *Logger) Warn(msg string, keyvals ...interface{}) {
	l.log(WARN, msg, keyvals...)
}

// Error logs at error level
func (l *Logger) Error(msg string, keyvals ...interface{}) {
	l.log(ERROR, msg, keyvals...)
}

// WithFields returns a new logger with predefined fields
func (l *Logger) WithFields(keyvals ...interface{}) *Logger {
	return &Logger{
		level:  l.level,
		format: l.format,
		output: l.output,
	}
}
