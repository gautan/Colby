package handlers

import (
	"net/http"
	"regexp"
	"strings"

	"github.com/elazarl/goproxy"
	"bl-go-proxy/internal/logger"
)

// RegisterBlockList registers the block list handler
func RegisterBlockList(proxy *goproxy.ProxyHttpServer, blockList []string, log *logger.Logger) {
	// Compile patterns (support wildcards)
	var patterns []*regexp.Regexp
	for _, entry := range blockList {
		// Convert wildcard to regex
		pattern := wildcardToRegex(entry)
		re, err := regexp.Compile(pattern)
		if err != nil {
			log.Error("Invalid block list pattern", "pattern", entry, "error", err)
			continue
		}
		patterns = append(patterns, re)
	}

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			host := r.Host
			// Remove port if present
			if idx := strings.LastIndex(host, ":"); idx != -1 {
				host = host[:idx]
			}

			for _, pattern := range patterns {
				if pattern.MatchString(host) || pattern.MatchString(r.URL.Host) {
					log.Warn("Blocked request",
						"host", host,
						"url", r.URL.String(),
						"remote_addr", r.RemoteAddr,
					)

					return r, goproxy.NewResponse(r,
						goproxy.ContentTypeText,
						http.StatusForbidden,
						"Access to this site is blocked by proxy policy",
					)
				}
			}

			return r, nil
		})
}

// RegisterAllowList registers the allow list handler (whitelist mode)
func RegisterAllowList(proxy *goproxy.ProxyHttpServer, allowList []string, log *logger.Logger) {
	// Compile patterns
	var patterns []*regexp.Regexp
	for _, entry := range allowList {
		pattern := wildcardToRegex(entry)
		re, err := regexp.Compile(pattern)
		if err != nil {
			log.Error("Invalid allow list pattern", "pattern", entry, "error", err)
			continue
		}
		patterns = append(patterns, re)
	}

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			host := r.Host
			if idx := strings.LastIndex(host, ":"); idx != -1 {
				host = host[:idx]
			}

			for _, pattern := range patterns {
				if pattern.MatchString(host) || pattern.MatchString(r.URL.Host) {
					// Allowed
					return r, nil
				}
			}

			// Not in allow list
			log.Warn("Request not in allow list",
				"host", host,
				"url", r.URL.String(),
				"remote_addr", r.RemoteAddr,
			)

			return r, goproxy.NewResponse(r,
				goproxy.ContentTypeText,
				http.StatusForbidden,
				"Access to this site is not allowed by proxy policy",
			)
		})
}

// wildcardToRegex converts a wildcard pattern to regex
func wildcardToRegex(pattern string) string {
	// Escape regex special characters except *
	result := regexp.QuoteMeta(pattern)
	// Replace escaped * with .*
	result = strings.ReplaceAll(result, `\*`, `.*`)
	// Make it a full match
	return "^" + result + "$"
}
