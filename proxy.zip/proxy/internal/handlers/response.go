package handlers

import (
	"bytes"
	"compress/gzip"
	"io"
	"net/http"
	"strings"

	"github.com/elazarl/goproxy"
	"github.com/yourorg/goproxy-custom/internal/config"
	"github.com/yourorg/goproxy-custom/internal/logger"
)

// RegisterResponseModifier registers response modification handlers
func RegisterResponseModifier(proxy *goproxy.ProxyHttpServer, cfg *config.Config, log *logger.Logger) {
	proxy.OnResponse().DoFunc(
		func(resp *http.Response, ctx *goproxy.ProxyCtx) *http.Response {
			if resp == nil {
				return nil
			}

			// Add proxy identifier header
			resp.Header.Set("X-Proxy", "goproxy-custom")

			// Remove server identification headers for security
			resp.Header.Del("Server")
			resp.Header.Del("X-Powered-By")

			return resp
		})
}

// ContentModifier allows modifying response body
type ContentModifier struct {
	log         *logger.Logger
	contentType string
	modifier    func([]byte) []byte
}

// NewContentModifier creates a new content modifier
func NewContentModifier(log *logger.Logger, contentType string, modifier func([]byte) []byte) *ContentModifier {
	return &ContentModifier{
		log:         log,
		contentType: contentType,
		modifier:    modifier,
	}
}

// Register registers the content modifier
func (cm *ContentModifier) Register(proxy *goproxy.ProxyHttpServer) {
	proxy.OnResponse().DoFunc(
		func(resp *http.Response, ctx *goproxy.ProxyCtx) *http.Response {
			if resp == nil || resp.Body == nil {
				return resp
			}

			contentType := resp.Header.Get("Content-Type")
			if !strings.Contains(contentType, cm.contentType) {
				return resp
			}

			// Read body
			body, err := readResponseBody(resp)
			if err != nil {
				cm.log.Error("Failed to read response body", "error", err)
				return resp
			}

			// Modify content
			modifiedBody := cm.modifier(body)

			// Update response
			resp.Body = io.NopCloser(bytes.NewReader(modifiedBody))
			resp.ContentLength = int64(len(modifiedBody))
			resp.Header.Set("Content-Length", string(rune(len(modifiedBody))))
			resp.Header.Del("Content-Encoding") // Remove compression header

			return resp
		})
}

// readResponseBody reads and decompresses response body if necessary
func readResponseBody(resp *http.Response) ([]byte, error) {
	var reader io.Reader = resp.Body
	defer resp.Body.Close()

	// Handle gzip encoding
	if resp.Header.Get("Content-Encoding") == "gzip" {
		gzReader, err := gzip.NewReader(resp.Body)
		if err != nil {
			return nil, err
		}
		defer gzReader.Close()
		reader = gzReader
	}

	return io.ReadAll(reader)
}

// InjectScript injects a script tag into HTML responses
func InjectScript(proxy *goproxy.ProxyHttpServer, scriptURL string, log *logger.Logger) {
	modifier := NewContentModifier(log, "text/html", func(body []byte) []byte {
		scriptTag := []byte(`<script src="` + scriptURL + `"></script>`)
		// Insert before </body>
		return bytes.Replace(body, []byte("</body>"), append(scriptTag, []byte("</body>")...), 1)
	})
	modifier.Register(proxy)
}

// ReplaceContent replaces content in responses
func ReplaceContent(proxy *goproxy.ProxyHttpServer, contentType, search, replace string, log *logger.Logger) {
	modifier := NewContentModifier(log, contentType, func(body []byte) []byte {
		return bytes.ReplaceAll(body, []byte(search), []byte(replace))
	})
	modifier.Register(proxy)
}
