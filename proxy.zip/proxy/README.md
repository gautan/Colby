# GoProxy Custom

A customizable HTTP/HTTPS proxy server built with Go using the [goproxy](https://github.com/elazarl/goproxy) library.

## Features

- **Request/Response Logging** - Detailed logging with configurable verbosity
- **Authentication** - Basic, Bearer token, and API key authentication
- **Rate Limiting** - Token bucket rate limiting per IP or global
- **Header Manipulation** - Add/remove headers on requests and responses
- **URL Rewriting** - Regex-based URL rewriting rules
- **Block/Allow Lists** - Domain filtering with wildcard support
- **Response Modification** - Modify response bodies (HTML injection, content replacement)

## Project Structure

```
proxy/
├── cmd/
│   └── proxy/
│       └── main.go           # Application entry point
├── internal/
│   ├── config/
│   │   └── config.go         # Configuration loading and structs
│   ├── handlers/
│   │   ├── blocklist.go      # Block/allow list handlers
│   │   └── response.go       # Response modification handlers
│   ├── logger/
│   │   └── logger.go         # Structured logging
│   └── middleware/
│       ├── auth.go           # Authentication middleware
│       ├── headers.go        # Header manipulation
│       ├── logging.go        # Request/response logging
│       ├── ratelimit.go      # Rate limiting
│       └── rewrite.go        # URL rewriting
├── examples/
│   └── ...                   # Usage examples
├── docs/
│   └── ...                   # Additional documentation
├── config.yaml               # Configuration file
├── go.mod                    # Go module definition
└── README.md                 # This file
```

## Quick Start

### Prerequisites

- Go 1.21 or later

### Installation

```bash
# Clone or navigate to the project
cd proxy

# Download dependencies
go mod tidy

# Build the proxy
go build -o bl-go-proxy ./cmd/proxy

# Run with default config
./bl-go-proxy

# Run with custom config
./bl-go-proxy -config /path/to/config.yaml
```

### Using as a Proxy

```bash
# Set HTTP proxy environment variable
export http_proxy=http://localhost:8080
export https_proxy=http://localhost:8080

# Or use curl directly
curl -x http://localhost:8080 http://example.com

# With proxy authentication (if enabled)
curl -x http://localhost:8080 -H "X-API-Key: sk-abc123def456" http://example.com
```

## Configuration

### Server Settings

```yaml
server:
  port: "8080"           # Listen port
  verbose: false         # Enable verbose goproxy logging
  read_timeout: 30s      # HTTP read timeout
  write_timeout: 30s     # HTTP write timeout
  idle_timeout: 60s      # Keep-alive timeout
```

### Logging

```yaml
logging:
  level: "info"          # debug, info, warn, error
  format: "text"         # json, text
```

### Authentication

#### Basic Authentication

```yaml
middleware:
  auth:
    enabled: true
    type: "basic"
    users:
      admin: "secretpassword"
      user1: "password123"
```

#### API Key Authentication

```yaml
middleware:
  auth:
    enabled: true
    type: "api_key"
    header_name: "X-API-Key"
    api_keys:
      - "sk-abc123def456"
      - "sk-xyz789ghi012"
```

#### Bearer Token Authentication

```yaml
middleware:
  auth:
    enabled: true
    type: "bearer"
    api_keys:
      - "token-abc123"
      - "token-xyz789"
```

### Rate Limiting

```yaml
middleware:
  rate_limit:
    enabled: true
    requests_per_sec: 100    # Refill rate
    burst_size: 50           # Max burst
    by_ip: true              # Per-IP or global
```

### Header Manipulation

```yaml
middleware:
  headers:
    enabled: true
    add_request:
      X-Forwarded-By: "bl-go-proxy"
    remove_request:
      - "X-Debug"
    add_response:
      Strict-Transport-Security: "max-age=31536000"
    remove_response:
      - "Server"
      - "X-Powered-By"
```

### URL Rewriting

```yaml
middleware:
  rewrite:
    enabled: true
    rules:
      - match: "^http://old-api.example.com/(.*)"
        replace: "http://new-api.example.com/$1"
      - match: "^http://(.+)/api/v1/(.*)"
        replace: "http://$1/api/v2/$2"
```

### Domain Filtering

#### Block List (Blacklist)

```yaml
handlers:
  block_list:
    - "*.malware.com"
    - "ads.example.com"
    - "tracker.analytics.com"
```

#### Allow List (Whitelist)

```yaml
handlers:
  allow_list:
    - "*.company.com"
    - "api.trusted-service.com"
```

## Adding Custom Features

### Adding a New Middleware

1. Create a new file in `internal/middleware/`:

```go
// internal/middleware/custom.go
package middleware

import (
    "net/http"
    "github.com/elazarl/goproxy"
    "github.com/yourorg/bl-go-proxy/internal/logger"
)

func RegisterCustomMiddleware(proxy *goproxy.ProxyHttpServer, log *logger.Logger) {
    // Request handler
    proxy.OnRequest().DoFunc(
        func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
            // Your custom logic here
            log.Info("Custom middleware triggered", "url", r.URL.String())

            // Return modified request, or return response to short-circuit
            return r, nil
        })

    // Response handler
    proxy.OnResponse().DoFunc(
        func(resp *http.Response, ctx *goproxy.ProxyCtx) *http.Response {
            if resp == nil {
                return nil
            }
            // Your custom logic here
            return resp
        })
}
```

2. Add configuration in `internal/config/config.go`:

```go
type CustomMiddlewareConfig struct {
    Enabled bool   `yaml:"enabled"`
    Option1 string `yaml:"option1"`
}
```

3. Register in `cmd/proxy/main.go`:

```go
if cfg.Middleware.Custom.Enabled {
    middleware.RegisterCustomMiddleware(proxy, cfg.Middleware.Custom, appLogger)
}
```

### Adding a Conditional Handler

```go
// Handle only specific hosts
proxy.OnRequest(goproxy.DstHostIs("api.example.com")).DoFunc(
    func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
        // Only executes for api.example.com
        return r, nil
    })

// Handle only specific methods
proxy.OnRequest(goproxy.ReqMethodIs("POST", "PUT")).DoFunc(
    func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
        // Only executes for POST and PUT requests
        return r, nil
    })

// Handle with custom condition
proxy.OnRequest(goproxy.ReqCondition(func(r *http.Request) bool {
    return r.Header.Get("X-Custom-Header") != ""
})).DoFunc(
    func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
        // Only executes when X-Custom-Header is present
        return r, nil
    })
```

### Modifying Response Body

```go
proxy.OnResponse().DoFunc(
    func(resp *http.Response, ctx *goproxy.ProxyCtx) *http.Response {
        if resp == nil || resp.Body == nil {
            return resp
        }

        // Read body
        body, err := io.ReadAll(resp.Body)
        resp.Body.Close()
        if err != nil {
            return resp
        }

        // Modify body
        modifiedBody := bytes.ReplaceAll(body, []byte("old"), []byte("new"))

        // Update response
        resp.Body = io.NopCloser(bytes.NewReader(modifiedBody))
        resp.ContentLength = int64(len(modifiedBody))
        resp.Header.Set("Content-Length", strconv.Itoa(len(modifiedBody)))

        return resp
    })
```

### HTTPS MITM (Man-in-the-Middle)

```go
// Enable HTTPS interception
proxy.OnRequest().HandleConnect(goproxy.AlwaysMitm)

// Or for specific hosts only
proxy.OnRequest(goproxy.DstHostIs("api.example.com")).HandleConnect(goproxy.AlwaysMitm)
```

**Note:** HTTPS MITM requires installing the proxy's CA certificate on clients.

## API Reference

### goproxy Key Types

| Type | Description |
|------|-------------|
| `*goproxy.ProxyHttpServer` | Main proxy server |
| `*goproxy.ProxyCtx` | Request context (stores user data between handlers) |
| `goproxy.ReqConditionFunc` | Function to match requests |
| `goproxy.RespConditionFunc` | Function to match responses |

### Built-in Conditions

| Condition | Description |
|-----------|-------------|
| `goproxy.DstHostIs("host")` | Match destination host |
| `goproxy.UrlHasPrefix("prefix")` | Match URL prefix |
| `goproxy.UrlIs("url")` | Match exact URL |
| `goproxy.ReqHostMatches(regexp)` | Match host with regex |
| `goproxy.ReqMethodIs("GET", ...)` | Match HTTP methods |
| `goproxy.ContentTypeIs("type")` | Match response content type |
| `goproxy.StatusCodeIs(200, ...)` | Match response status codes |

### Creating Responses

```go
// Text response
goproxy.NewResponse(req, goproxy.ContentTypeText, http.StatusOK, "Hello")

// HTML response
goproxy.NewResponse(req, goproxy.ContentTypeHtml, http.StatusOK, "<h1>Hello</h1>")

// JSON response (custom)
resp := &http.Response{
    StatusCode: http.StatusOK,
    ProtoMajor: 1,
    ProtoMinor: 1,
    Header:     make(http.Header),
    Body:       io.NopCloser(bytes.NewBufferString(`{"status":"ok"}`)),
    Request:    req,
}
resp.Header.Set("Content-Type", "application/json")
```

## Testing

```bash
# Run tests
go test ./...

# Run with coverage
go test -cover ./...

# Run specific package tests
go test ./internal/middleware/...
```

## Docker

```dockerfile
FROM golang:1.21-alpine AS builder
WORKDIR /app
COPY . .
RUN go build -o bl-go-proxy ./cmd/proxy

FROM alpine:latest
RUN apk --no-cache add ca-certificates
WORKDIR /app
COPY --from=builder /app/bl-go-proxy .
COPY config.yaml .
EXPOSE 8080
CMD ["./bl-go-proxy"]
```

```bash
# Build and run
docker build -t bl-go-proxy .
docker run -p 8080:8080 bl-go-proxy
```

## License

MIT License
