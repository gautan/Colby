// Package main demonstrates proxy with authentication
package main

import (
	"encoding/base64"
	"log"
	"net/http"
	"strings"

	"github.com/elazarl/goproxy"
)

// Valid users for basic auth
var validUsers = map[string]string{
	"admin": "secret123",
	"user":  "password",
}

func main() {
	proxy := goproxy.NewProxyHttpServer()

	// Add basic authentication
	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			auth := r.Header.Get("Proxy-Authorization")
			if auth == "" {
				return r, requireAuth(r)
			}

			if !strings.HasPrefix(auth, "Basic ") {
				return r, requireAuth(r)
			}

			decoded, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(auth, "Basic "))
			if err != nil {
				return r, requireAuth(r)
			}

			parts := strings.SplitN(string(decoded), ":", 2)
			if len(parts) != 2 {
				return r, requireAuth(r)
			}

			username, password := parts[0], parts[1]
			if expectedPassword, ok := validUsers[username]; ok && expectedPassword == password {
				log.Printf("Authenticated user: %s", username)
				// Remove auth header before forwarding
				r.Header.Del("Proxy-Authorization")
				return r, nil
			}

			return r, requireAuth(r)
		})

	log.Println("Starting authenticated proxy on :8080")
	log.Println("Use: curl -x http://admin:secret123@localhost:8080 http://example.com")
	log.Fatal(http.ListenAndServe(":8080", proxy))
}

func requireAuth(r *http.Request) *http.Response {
	resp := goproxy.NewResponse(r,
		goproxy.ContentTypeText,
		http.StatusProxyAuthRequired,
		"Proxy authentication required",
	)
	resp.Header.Set("Proxy-Authenticate", `Basic realm="Proxy"`)
	return resp
}
