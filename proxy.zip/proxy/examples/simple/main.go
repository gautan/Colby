// Package main demonstrates a simple proxy setup
package main

import (
	"log"
	"net/http"

	"github.com/elazarl/goproxy"
)

func main() {
	proxy := goproxy.NewProxyHttpServer()
	proxy.Verbose = true

	// Simple request logger
	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			log.Printf("Request: %s %s", r.Method, r.URL)
			return r, nil
		})

	// Simple response logger
	proxy.OnResponse().DoFunc(
		func(resp *http.Response, ctx *goproxy.ProxyCtx) *http.Response {
			if resp != nil {
				log.Printf("Response: %d %s", resp.StatusCode, ctx.Req.URL)
			}
			return resp
		})

	log.Println("Starting proxy on :8080")
	log.Fatal(http.ListenAndServe(":8080", proxy))
}
