// Package main demonstrates proxy with rate limiting
package main

import (
	"log"
	"net"
	"net/http"
	"sync"
	"time"

	"github.com/elazarl/goproxy"
)

// Simple token bucket rate limiter
type RateLimiter struct {
	mu      sync.Mutex
	buckets map[string]*bucket
	rate    float64 // tokens per second
	burst   int     // max tokens
}

type bucket struct {
	tokens     float64
	lastUpdate time.Time
}

func NewRateLimiter(rate float64, burst int) *RateLimiter {
	return &RateLimiter{
		buckets: make(map[string]*bucket),
		rate:    rate,
		burst:   burst,
	}
}

func (rl *RateLimiter) Allow(key string) bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	now := time.Now()
	b, exists := rl.buckets[key]
	if !exists {
		b = &bucket{tokens: float64(rl.burst), lastUpdate: now}
		rl.buckets[key] = b
	}

	// Refill tokens
	elapsed := now.Sub(b.lastUpdate).Seconds()
	b.tokens += elapsed * rl.rate
	if b.tokens > float64(rl.burst) {
		b.tokens = float64(rl.burst)
	}
	b.lastUpdate = now

	if b.tokens >= 1 {
		b.tokens--
		return true
	}
	return false
}

func getClientIP(r *http.Request) string {
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		return xff
	}
	ip, _, _ := net.SplitHostPort(r.RemoteAddr)
	return ip
}

func main() {
	proxy := goproxy.NewProxyHttpServer()

	// 10 requests per second, burst of 5
	limiter := NewRateLimiter(10, 5)

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			clientIP := getClientIP(r)

			if !limiter.Allow(clientIP) {
				log.Printf("Rate limited: %s", clientIP)
				resp := goproxy.NewResponse(r,
					goproxy.ContentTypeText,
					http.StatusTooManyRequests,
					"Rate limit exceeded. Please slow down.",
				)
				resp.Header.Set("Retry-After", "1")
				return r, resp
			}

			log.Printf("Allowed: %s -> %s", clientIP, r.URL)
			return r, nil
		})

	log.Println("Starting rate-limited proxy on :8080")
	log.Println("Rate limit: 10 req/sec per IP, burst of 5")
	log.Fatal(http.ListenAndServe(":8080", proxy))
}
