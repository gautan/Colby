// Package main demonstrates proxy with URL rewriting
package main

import (
	"log"
	"net/http"
	"net/url"
	"regexp"

	"github.com/elazarl/goproxy"
)

// RewriteRule defines a URL rewrite rule
type RewriteRule struct {
	Pattern *regexp.Regexp
	Replace string
}

func main() {
	proxy := goproxy.NewProxyHttpServer()
	proxy.Verbose = true

	// Define rewrite rules
	rules := []RewriteRule{
		// Rewrite old API to new API
		{
			Pattern: regexp.MustCompile(`^http://api\.old\.com/(.*)$`),
			Replace: "http://api.new.com/$1",
		},
		// Rewrite v1 to v2 API
		{
			Pattern: regexp.MustCompile(`^(https?://[^/]+)/api/v1/(.*)$`),
			Replace: "${1}/api/v2/${2}",
		},
		// Add prefix to certain paths
		{
			Pattern: regexp.MustCompile(`^(https?://[^/]+)/users/(.*)$`),
			Replace: "${1}/api/users/${2}",
		},
	}

	proxy.OnRequest().DoFunc(
		func(r *http.Request, ctx *goproxy.ProxyCtx) (*http.Request, *http.Response) {
			originalURL := r.URL.String()

			for _, rule := range rules {
				if rule.Pattern.MatchString(originalURL) {
					newURLStr := rule.Pattern.ReplaceAllString(originalURL, rule.Replace)

					newURL, err := url.Parse(newURLStr)
					if err != nil {
						log.Printf("Failed to parse rewritten URL: %s", err)
						continue
					}

					log.Printf("Rewritten: %s -> %s", originalURL, newURLStr)

					r.URL = newURL
					if newURL.Host != "" {
						r.Host = newURL.Host
					}
					break // Apply first matching rule
				}
			}

			return r, nil
		})

	log.Println("Starting URL rewriting proxy on :8080")
	log.Println("Rules:")
	log.Println("  - api.old.com/* -> api.new.com/*")
	log.Println("  - */api/v1/* -> */api/v2/*")
	log.Println("  - */users/* -> */api/users/*")
	log.Fatal(http.ListenAndServe(":8080", proxy))
}
