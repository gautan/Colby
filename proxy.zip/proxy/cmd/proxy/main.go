package main

import (
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	"bl-go-proxy/internal/config"
	"bl-go-proxy/internal/handlers"
	"bl-go-proxy/internal/logger"
	"bl-go-proxy/internal/middleware"

	"github.com/elazarl/goproxy"
)

func main() {
	// Parse command line flags
	configPath := flag.String("config", "config.yaml", "Path to configuration file")
	flag.Parse()

	// Load configuration
	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Printf("Warning: Could not load config file, using defaults: %v", err)
		cfg = config.Default()
	}

	// Initialize logger
	appLogger := logger.New(cfg.Logging.Level, cfg.Logging.Format)
	appLogger.Info("Starting proxy server", "port", cfg.Server.Port)

	// Create proxy server
	proxy := goproxy.NewProxyHttpServer()
	proxy.Verbose = cfg.Server.Verbose

	// Handle direct (non-proxy) HTTP requests by converting them to
	// absolute-URI form so goproxy processes them through the normal
	// OnRequest middleware chain.
	proxy.NonproxyHandler = http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		if req.URL.Scheme == "" {
			req.URL.Scheme = "http"
		}
		if req.URL.Host == "" {
			req.URL.Host = req.Host
		}
		proxy.ServeHTTP(w, req)
	})

	// Register middleware chain
	registerMiddleware(proxy, cfg, appLogger)

	// Register handlers
	registerHandlers(proxy, cfg, appLogger)

	// Create HTTP server
	server := &http.Server{
		Addr:         ":" + cfg.Server.Port,
		Handler:      proxy,
		ReadTimeout:  cfg.Server.ReadTimeout,
		WriteTimeout: cfg.Server.WriteTimeout,
		IdleTimeout:  cfg.Server.IdleTimeout,
	}

	// Graceful shutdown
	go func() {
		sigChan := make(chan os.Signal, 1)
		signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
		<-sigChan
		appLogger.Info("Shutting down proxy server...")
		server.Close()
	}()

	// Start server
	appLogger.Info("Proxy server listening", "address", server.Addr)
	if err := server.ListenAndServe(); err != http.ErrServerClosed {
		appLogger.Error("Server error", "error", err)
		os.Exit(1)
	}
}

func registerMiddleware(proxy *goproxy.ProxyHttpServer, cfg *config.Config, log *logger.Logger) {
	// 1. Request logging middleware
	if cfg.Middleware.Logging.Enabled {
		middleware.RegisterLogging(proxy, log)
	}

	// 2. Authentication middleware
	if cfg.Middleware.Auth.Enabled {
		middleware.RegisterAuth(proxy, cfg.Middleware.Auth, log)
	}

	// 3. Rate limiting middleware
	if cfg.Middleware.RateLimit.Enabled {
		middleware.RegisterRateLimit(proxy, cfg.Middleware.RateLimit, log)
	}

	// 4. Header manipulation middleware
	if cfg.Middleware.Headers.Enabled {
		middleware.RegisterHeaders(proxy, cfg.Middleware.Headers, log)
	}

	// 5. URL rewriting middleware
	if cfg.Middleware.Rewrite.Enabled {
		middleware.RegisterRewrite(proxy, cfg.Middleware.Rewrite, log)
	}

	// 6. Provider-based URL rewriting
	if len(cfg.Providers) > 0 {
		middleware.RegisterProviderRewrite(proxy, cfg.Providers, log)
	}
}

func registerHandlers(proxy *goproxy.ProxyHttpServer, cfg *config.Config, log *logger.Logger) {
	// Block list handler
	if len(cfg.Handlers.BlockList) > 0 {
		handlers.RegisterBlockList(proxy, cfg.Handlers.BlockList, log)
	}

	// Allow list handler (whitelist mode)
	if len(cfg.Handlers.AllowList) > 0 {
		handlers.RegisterAllowList(proxy, cfg.Handlers.AllowList, log)
	}

	// Custom response handlers
	handlers.RegisterResponseModifier(proxy, cfg, log)
}
