import winston from 'winston';

export interface Logger {
  debug(message: string, meta?: Record<string, unknown>): void;
  info(message: string, meta?: Record<string, unknown>): void;
  warn(message: string, meta?: Record<string, unknown>): void;
  error(message: string, meta?: Record<string, unknown>): void;
}

export function createLogger(level: string, format: string): Logger {
  const logFormat = format === 'json'
    ? winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
      )
    : winston.format.combine(
        winston.format.timestamp(),
        winston.format.colorize(),
        winston.format.printf(({ timestamp, level, message, ...meta }) => {
          const metaStr = Object.keys(meta).length
            ? ' ' + Object.entries(meta).map(([k, v]) => `${k}=${v}`).join(' ')
            : '';
          return `${timestamp} [${level}] ${message}${metaStr}`;
        })
      );

  const winstonLogger = winston.createLogger({
    level,
    format: logFormat,
    transports: [
      new winston.transports.Console(),
    ],
  });

  return {
    debug: (message: string, meta?: Record<string, unknown>) => {
      winstonLogger.debug(message, meta);
    },
    info: (message: string, meta?: Record<string, unknown>) => {
      winstonLogger.info(message, meta);
    },
    warn: (message: string, meta?: Record<string, unknown>) => {
      winstonLogger.warn(message, meta);
    },
    error: (message: string, meta?: Record<string, unknown>) => {
      winstonLogger.error(message, meta);
    },
  };
}
