import { Request, Response, NextFunction } from 'express';
import { RewriteMiddlewareConfig, RewriteRule } from '../config/config';
import { Logger } from '../logger/logger';

interface CompiledRule {
  pattern: RegExp;
  replace: string;
}

export function createRewriteMiddleware(config: RewriteMiddlewareConfig, logger: Logger) {
  // Compile all rules
  const compiledRules: CompiledRule[] = [];

  for (const rule of config.rules) {
    try {
      const pattern = new RegExp(rule.match);
      compiledRules.push({
        pattern,
        replace: rule.replace,
      });
    } catch (error) {
      logger.error('Invalid rewrite pattern', {
        pattern: rule.match,
        error: String(error),
      });
    }
  }

  return (req: Request, res: Response, next: NextFunction) => {
    const originalUrl = req.url;

    for (const rule of compiledRules) {
      if (rule.pattern.test(originalUrl)) {
        const newUrl = originalUrl.replace(rule.pattern, rule.replace);

        logger.debug('URL rewritten', {
          original: originalUrl,
          rewritten: newUrl,
        });

        req.url = newUrl;
        break; // Apply first matching rule only
      }
    }

    next();
  };
}

export function createPathPrefixRewrite(prefix: string, replacement: string, logger: Logger) {
  const pattern = new RegExp('^' + escapeRegExp(prefix));

  return (req: Request, res: Response, next: NextFunction) => {
    if (pattern.test(req.path)) {
      const originalPath = req.path;
      req.url = req.url.replace(pattern, replacement);

      logger.debug('Path prefix rewritten', {
        original: originalPath,
        rewritten: req.path,
      });
    }

    next();
  };
}

function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
