import { IncomingMessage } from 'http';
import { Request, Response, NextFunction } from 'express';
import { Provider } from '../config/config';
import { Logger } from '../logger/logger';

/**
 * Resolved provider target attached to the request during the middleware phase.
 * The proxy router function reads this to select the correct upstream.
 */
export interface ResolvedProvider {
  target: string;
  provider: Provider;
}

declare global {
  namespace Express {
    interface Request {
      resolvedProvider?: ResolvedProvider;
    }
  }
}

/**
 * Build the full target origin URL for a provider.
 * e.g. "https://contarchstgwlp.barcapint.com:443"
 */
function buildProviderTarget(provider: Provider): string {
  const scheme = provider.useHttps ? 'https' : 'http';
  if (provider.port) {
    return `${scheme}://${provider.host}:${provider.port}`;
  }
  return `${scheme}://${provider.host}`;
}

/**
 * Provider-based URL rewriting middleware.
 *
 * Matches the first path segment (case-insensitive) against the providers map.
 * When matched, attaches `req.resolvedProvider` so the proxy router function
 * can forward the request to the correct upstream.
 *
 * URL pattern:
 *   INPUT:  /{CP}/{path}?{query}
 *   OUTPUT: proxied to {scheme}://{host}:{port}/{CP}/{path}?{query}
 *
 * The full original path (including the CP segment) is preserved — matching
 * the Go proxy behavior.
 */
export function createProviderMiddleware(
  providers: Record<string, Provider>,
  logger: Logger,
) {
  // Pre-compute targets and log registration
  const targets = new Map<string, { target: string; provider: Provider }>();

  for (const [key, provider] of Object.entries(providers)) {
    const target = buildProviderTarget(provider);
    targets.set(key.toUpperCase(), { target, provider });
    logger.info('Registered content provider', {
      name: key,
      target,
      region: provider.region,
      skipTlsVerify: provider.skipTlsVerify,
    });
  }

  return (req: Request, res: Response, next: NextFunction) => {
    const path = req.path;
    if (!path || path === '/') {
      return next();
    }

    // Extract first path segment as the content provider name
    const trimmed = path.startsWith('/') ? path.slice(1) : path;
    const slashIndex = trimmed.indexOf('/');
    const cpName = (slashIndex === -1 ? trimmed : trimmed.slice(0, slashIndex)).toUpperCase();

    const entry = targets.get(cpName);
    if (!entry) {
      return next(); // Not a provider route, pass through
    }

    logger.info('Provider rewrite', {
      provider: cpName,
      original: req.originalUrl,
      target: `${entry.target}${req.originalUrl}`,
    });

    // Preserve original host in X-Forwarded-Host
    req.headers['x-forwarded-host'] = req.headers.host || '';

    // Attach resolved provider for the proxy router function
    req.resolvedProvider = {
      target: entry.target,
      provider: entry.provider,
    };

    next();
  };
}

/**
 * Returns a router function compatible with http-proxy-middleware's `router` option.
 * Checks for a resolved provider on the request; falls back to the default target.
 */
export function createProviderRouter(defaultTarget: string) {
  return (req: IncomingMessage): string => {
    const expressReq = req as Request;
    if (expressReq.resolvedProvider) {
      return expressReq.resolvedProvider.target;
    }
    return defaultTarget;
  };
}
