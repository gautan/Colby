import { Request, Response, NextFunction } from 'express';
import { RateLimitMiddlewareConfig } from '../config/config';
import { Logger } from '../logger/logger';

interface Bucket {
  tokens: number;
  lastUpdate: number;
}

class RateLimiter {
  private buckets: Map<string, Bucket> = new Map();
  private rate: number;
  private burst: number;
  private byIP: boolean;
  private cleanupInterval: NodeJS.Timeout;

  constructor(rate: number, burst: number, byIP: boolean) {
    this.rate = rate;
    this.burst = burst;
    this.byIP = byIP;

    // Cleanup old entries every minute
    this.cleanupInterval = setInterval(() => this.cleanup(), 60000);
  }

  private cleanup(): void {
    const now = Date.now();
    const fiveMinutes = 5 * 60 * 1000;

    for (const [key, bucket] of this.buckets) {
      if (now - bucket.lastUpdate > fiveMinutes) {
        this.buckets.delete(key);
      }
    }
  }

  getKey(req: Request): string {
    if (this.byIP) {
      // Check X-Forwarded-For header first
      const xff = req.get('X-Forwarded-For');
      if (xff) {
        return xff.split(',')[0].trim();
      }
      // Check X-Real-IP header
      const xri = req.get('X-Real-IP');
      if (xri) {
        return xri;
      }
      // Fall back to req.ip
      return req.ip || 'unknown';
    }
    return 'global';
  }

  allow(key: string): boolean {
    const now = Date.now();
    let bucket = this.buckets.get(key);

    if (!bucket) {
      bucket = {
        tokens: this.burst,
        lastUpdate: now,
      };
      this.buckets.set(key, bucket);
    }

    // Refill tokens based on time elapsed
    const elapsed = (now - bucket.lastUpdate) / 1000;
    bucket.tokens = Math.min(this.burst, bucket.tokens + elapsed * this.rate);
    bucket.lastUpdate = now;

    // Check if we have tokens available
    if (bucket.tokens >= 1) {
      bucket.tokens--;
      return true;
    }

    return false;
  }

  destroy(): void {
    clearInterval(this.cleanupInterval);
  }
}

export function createRateLimitMiddleware(config: RateLimitMiddlewareConfig, logger: Logger) {
  const limiter = new RateLimiter(config.requestsPerSec, config.burstSize, config.byIP);

  return (req: Request, res: Response, next: NextFunction) => {
    const key = limiter.getKey(req);

    if (!limiter.allow(key)) {
      logger.warn('Rate limit exceeded', {
        key,
        method: req.method,
        url: req.url,
      });

      res.setHeader('Retry-After', '1');
      return res.status(429).json({
        error: 'Rate limit exceeded. Please slow down.',
      });
    }

    next();
  };
}
