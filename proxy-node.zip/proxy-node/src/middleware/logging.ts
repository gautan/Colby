import { Request, Response, NextFunction } from 'express';
import { LoggingMiddlewareConfig } from '../config/config';
import { Logger } from '../logger/logger';

export function createLoggingMiddleware(config: LoggingMiddlewareConfig, logger: Logger) {
  return (req: Request, res: Response, next: NextFunction) => {
    // Check if path should be excluded
    if (config.excludePaths.some(path => req.path.startsWith(path))) {
      return next();
    }

    const startTime = Date.now();

    // Log request
    logger.info('Request received', {
      method: req.method,
      url: req.url,
      host: req.hostname,
      remoteAddr: req.ip,
      userAgent: req.get('user-agent'),
      contentLength: req.get('content-length'),
    });

    // Capture response
    const originalSend = res.send;
    res.send = function(body) {
      const duration = Date.now() - startTime;

      logger.info('Response sent', {
        method: req.method,
        url: req.url,
        status: res.statusCode,
        durationMs: duration,
        contentLength: res.get('content-length'),
      });

      return originalSend.call(this, body);
    };

    next();
  };
}
