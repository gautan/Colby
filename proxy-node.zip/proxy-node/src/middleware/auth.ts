import { Request, Response, NextFunction } from 'express';
import { AuthMiddlewareConfig } from '../config/config';
import { Logger } from '../logger/logger';

interface AuthResult {
  authenticated: boolean;
  method: string;
}

function authenticateBasic(req: Request, users: Record<string, string>): AuthResult {
  const authHeader = req.get('Proxy-Authorization') || req.get('Authorization');

  if (!authHeader || !authHeader.startsWith('Basic ')) {
    return { authenticated: false, method: '' };
  }

  const base64Credentials = authHeader.slice(6);
  const credentials = Buffer.from(base64Credentials, 'base64').toString('utf-8');
  const [username, password] = credentials.split(':');

  if (users[username] && users[username] === password) {
    return { authenticated: true, method: `basic:${username}` };
  }

  return { authenticated: false, method: '' };
}

function authenticateBearer(req: Request, apiKeys: string[]): AuthResult {
  const authHeader = req.get('Authorization');

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return { authenticated: false, method: '' };
  }

  const token = authHeader.slice(7);

  if (apiKeys.includes(token)) {
    return { authenticated: true, method: 'bearer' };
  }

  return { authenticated: false, method: '' };
}

function authenticateApiKey(req: Request, headerName: string, apiKeys: string[]): AuthResult {
  const apiKey = req.get(headerName) || req.query.api_key as string;

  if (apiKey && apiKeys.includes(apiKey)) {
    return { authenticated: true, method: 'api_key' };
  }

  return { authenticated: false, method: '' };
}

export function createAuthMiddleware(config: AuthMiddlewareConfig, logger: Logger) {
  return (req: Request, res: Response, next: NextFunction) => {
    let result: AuthResult;

    switch (config.type) {
      case 'basic':
        result = authenticateBasic(req, config.users);
        break;
      case 'bearer':
        result = authenticateBearer(req, config.apiKeys);
        break;
      case 'api_key':
        result = authenticateApiKey(req, config.headerName, config.apiKeys);
        break;
      default:
        return next();
    }

    if (!result.authenticated) {
      logger.warn('Authentication failed', {
        method: req.method,
        url: req.url,
        remoteAddr: req.ip,
        authType: config.type,
      });

      return res.status(407).json({
        error: 'Proxy authentication required',
      });
    }

    logger.debug('Authentication successful', {
      method: req.method,
      url: req.url,
      authMethod: result.method,
    });

    next();
  };
}
