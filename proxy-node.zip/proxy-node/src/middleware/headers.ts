import { Request, Response, NextFunction } from 'express';
import { HeadersMiddlewareConfig } from '../config/config';
import { Logger } from '../logger/logger';

export function createRequestHeadersMiddleware(config: HeadersMiddlewareConfig, logger: Logger) {
  return (req: Request, res: Response, next: NextFunction) => {
    // Add headers
    for (const [key, value] of Object.entries(config.addRequest)) {
      req.headers[key.toLowerCase()] = value;
      logger.debug('Added request header', { key, value });
    }

    // Remove headers
    for (const key of config.removeRequest) {
      delete req.headers[key.toLowerCase()];
      logger.debug('Removed request header', { key });
    }

    next();
  };
}

export function createResponseHeadersMiddleware(config: HeadersMiddlewareConfig, logger: Logger) {
  return (req: Request, res: Response, next: NextFunction) => {
    // Store original setHeader
    const originalSetHeader = res.setHeader.bind(res);

    // Override to intercept response headers
    res.on('finish', () => {
      // This is called after headers are sent, for logging only
    });

    // Add response headers before sending
    const originalWriteHead = res.writeHead.bind(res);
    res.writeHead = function(
      statusCode: number,
      ...args: any[]
    ) {
      // Add headers
      for (const [key, value] of Object.entries(config.addResponse)) {
        res.setHeader(key, value);
        logger.debug('Added response header', { key, value });
      }

      // Remove headers
      for (const key of config.removeResponse) {
        res.removeHeader(key);
        logger.debug('Removed response header', { key });
      }

      return originalWriteHead(statusCode, ...args);
    } as typeof res.writeHead;

    next();
  };
}

export const commonSecurityHeaders: Record<string, string> = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'X-XSS-Protection': '1; mode=block',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
};

export function corsHeaders(allowOrigin: string): Record<string, string> {
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Max-Age': '86400',
  };
}
