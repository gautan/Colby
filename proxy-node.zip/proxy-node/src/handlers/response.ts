import { Request, Response, NextFunction } from 'express';
import { Logger } from '../logger/logger';

export function createResponseModifier(logger: Logger) {
  return (req: Request, res: Response, next: NextFunction) => {
    // Intercept writeHead to modify response headers
    const originalWriteHead = res.writeHead.bind(res);

    res.writeHead = function(
      statusCode: number,
      ...args: any[]
    ) {
      // Add proxy identifier header
      res.setHeader('X-Proxy', 'proxy-node');

      // Remove server identification headers for security
      res.removeHeader('Server');
      res.removeHeader('X-Powered-By');

      return originalWriteHead(statusCode, ...args);
    } as typeof res.writeHead;

    next();
  };
}

export interface ContentModifierOptions {
  contentType: string;
  modifier: (body: Buffer) => Buffer;
}

export function createContentModifier(options: ContentModifierOptions, logger: Logger) {
  return (req: Request, res: Response, next: NextFunction) => {
    const originalWrite = res.write.bind(res);
    const originalEnd = res.end.bind(res);
    const chunks: Buffer[] = [];

    res.write = function(chunk: any, ...args: any[]) {
      const contentType = res.getHeader('content-type') as string || '';

      if (contentType.includes(options.contentType)) {
        chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
        return true;
      }

      return originalWrite(chunk, ...args);
    };

    res.end = function(chunk?: any, ...args: any[]) {
      const contentType = res.getHeader('content-type') as string || '';

      if (contentType.includes(options.contentType)) {
        if (chunk) {
          chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
        }

        const body = Buffer.concat(chunks);
        const modifiedBody = options.modifier(body);

        res.setHeader('Content-Length', modifiedBody.length);
        res.removeHeader('Content-Encoding');

        return originalEnd(modifiedBody);
      }

      return originalEnd(chunk, ...args);
    };

    next();
  };
}

export function injectScript(scriptUrl: string, logger: Logger) {
  return createContentModifier({
    contentType: 'text/html',
    modifier: (body: Buffer) => {
      const html = body.toString();
      const scriptTag = `<script src="${scriptUrl}"></script>`;
      const modified = html.replace('</body>', `${scriptTag}</body>`);
      return Buffer.from(modified);
    },
  }, logger);
}

export function replaceContent(
  contentType: string,
  search: string,
  replace: string,
  logger: Logger
) {
  return createContentModifier({
    contentType,
    modifier: (body: Buffer) => {
      const content = body.toString();
      const modified = content.split(search).join(replace);
      return Buffer.from(modified);
    },
  }, logger);
}
