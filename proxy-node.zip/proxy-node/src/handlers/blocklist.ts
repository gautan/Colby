import { Request, Response, NextFunction } from 'express';
import { Logger } from '../logger/logger';

function wildcardToRegex(pattern: string): RegExp {
  // Escape regex special characters except *
  const escaped = pattern.replace(/[.+?^${}()|[\]\\]/g, '\\$&');
  // Replace * with .*
  const regexPattern = escaped.replace(/\*/g, '.*');
  return new RegExp(`^${regexPattern}$`);
}

export function createBlockListMiddleware(blockList: string[], logger: Logger) {
  const patterns = blockList.map(entry => {
    try {
      return wildcardToRegex(entry);
    } catch (error) {
      logger.error('Invalid block list pattern', {
        pattern: entry,
        error: String(error),
      });
      return null;
    }
  }).filter((p): p is RegExp => p !== null);

  return (req: Request, res: Response, next: NextFunction) => {
    const host = req.hostname || req.get('host')?.split(':')[0] || '';

    for (const pattern of patterns) {
      if (pattern.test(host)) {
        logger.warn('Blocked request', {
          host,
          url: req.url,
          remoteAddr: req.ip,
        });

        return res.status(403).json({
          error: 'Access to this site is blocked by proxy policy',
        });
      }
    }

    next();
  };
}

export function createAllowListMiddleware(allowList: string[], logger: Logger) {
  const patterns = allowList.map(entry => {
    try {
      return wildcardToRegex(entry);
    } catch (error) {
      logger.error('Invalid allow list pattern', {
        pattern: entry,
        error: String(error),
      });
      return null;
    }
  }).filter((p): p is RegExp => p !== null);

  return (req: Request, res: Response, next: NextFunction) => {
    const host = req.hostname || req.get('host')?.split(':')[0] || '';

    for (const pattern of patterns) {
      if (pattern.test(host)) {
        return next(); // Allowed
      }
    }

    // Not in allow list
    logger.warn('Request not in allow list', {
      host,
      url: req.url,
      remoteAddr: req.ip,
    });

    return res.status(403).json({
      error: 'Access to this site is not allowed by proxy policy',
    });
  };
}
