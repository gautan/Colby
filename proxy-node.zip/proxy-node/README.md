# Proxy Node

A customizable HTTP proxy server built with Node.js, TypeScript, and Express using `http-proxy-middleware`.

## Features

- **Configurable via YAML** - Easy configuration using YAML files
- **Middleware Chain** - Extensible middleware architecture
- **Authentication** - Basic auth, Bearer token, and API key support
- **Rate Limiting** - Token bucket rate limiting per IP or global
- **Header Manipulation** - Add/remove request and response headers
- **URL Rewriting** - Regex-based URL rewriting
- **Block/Allow Lists** - Domain filtering with wildcard support
- **Response Modification** - Modify response content
- **Structured Logging** - JSON or text format logging with Winston
- **WebSocket Support** - Full WebSocket proxying capability

## Installation

```bash
# Install dependencies
npm install

# Build TypeScript
npm run build

# Start the server
npm start

# Or run in development mode
npm run dev
```

## Configuration

Edit `config.yaml` to customize the proxy behavior:

```yaml
server:
  port: 8080
  target: "https://httpbin.org"
  verbose: true

logging:
  level: "info"    # debug, info, warn, error
  format: "json"   # json or text

middleware:
  logging:
    enabled: true
    excludePaths:
      - "/health"

  auth:
    enabled: false
    type: "basic"  # basic, bearer, api_key
    users:
      admin: "admin123"
    apiKeys:
      - "key-123"
    headerName: "X-API-Key"

  rateLimit:
    enabled: true
    requestsPerSec: 100
    burstSize: 50
    byIP: true

  headers:
    enabled: true
    addRequest:
      X-Forwarded-By: "proxy-node"
    removeRequest:
      - "X-Debug"
    addResponse:
      X-Proxy-By: "proxy-node"
    removeResponse:
      - "Server"

  rewrite:
    enabled: false
    rules:
      - match: "^/api/v1/(.*)"
        replace: "/v1/$1"

handlers:
  blockList:
    - "*.malware.com"
  allowList: []
```

## Usage

### Basic Usage

```bash
# Start with default config
npm start

# Start with custom config
npm start -- /path/to/config.yaml

# Development mode with auto-reload
npm run dev
```

### Docker

```bash
# Build image
docker build -t proxy-node .

# Run container
docker run -p 8080:8080 proxy-node

# Run with custom config
docker run -p 8080:8080 -v $(pwd)/custom-config.yaml:/app/config.yaml proxy-node
```

### Testing the Proxy

```bash
# Test basic proxying
curl -x http://localhost:8080 http://httpbin.org/get

# Test with authentication (if enabled)
curl -x http://localhost:8080 -U admin:admin123 http://httpbin.org/get

# Test rate limiting
for i in {1..100}; do curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8080/get; done
```

## Middleware

### Authentication

Supports three authentication types:

- **Basic Auth**: Username/password in Proxy-Authorization header
- **Bearer Token**: Token in Authorization header
- **API Key**: Key in custom header or query parameter

### Rate Limiting

Token bucket algorithm with configurable:
- Requests per second
- Burst size
- Per-IP or global limiting

### Header Manipulation

Add or remove headers on:
- Incoming requests
- Outgoing responses

### URL Rewriting

Regex-based URL rewriting with capture groups:

```yaml
rules:
  - match: "^/api/v1/(.*)"
    replace: "/v1/$1"
```

## API Endpoints

- `GET /health` - Health check endpoint (not proxied)

## Project Structure

```
proxy-node/
├── src/
│   ├── index.ts              # Main entry point
│   ├── config/
│   │   └── config.ts         # Configuration loader
│   ├── middleware/
│   │   ├── index.ts          # Middleware exports
│   │   ├── logging.ts        # Request/response logging
│   │   ├── auth.ts           # Authentication
│   │   ├── ratelimit.ts      # Rate limiting
│   │   ├── headers.ts        # Header manipulation
│   │   └── rewrite.ts        # URL rewriting
│   ├── handlers/
│   │   ├── index.ts          # Handler exports
│   │   ├── blocklist.ts      # Block/allow lists
│   │   └── response.ts       # Response modification
│   └── logger/
│       └── logger.ts         # Winston logger
├── config.yaml               # Default configuration
├── package.json
├── tsconfig.json
├── Dockerfile
└── README.md
```

## License

MIT
